package com.example.flutter_sound

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
