## [0.1.9] - 15.10.2018
* Support Motion permission (iOS)
* Reduce minimum iOS deployment target to 9.3

## [0.1.8] - 24.09.2018
* Targeting Android API 27

## [0.1.7] - 11.09.2018
* Android Send SMS

## [0.1.6] - 10.08.2018
* See commits for changelogs

## [0.1.5] - 22.05.2018
* Added Vibrate (Android)

## [0.1.4] - 11.05.2018
* Added Read External Storage (Android)

## [0.1.3] - 01.05.2018
* Added contact permission

## [0.1.2] - 13.04.2018
* Added method for getting permission status from iOs

## [0.1.1] - 26.03.2018

* Fix for Dart 2.0 compatibility

## [0.1.0] - 14.03.2018

* Initial release
