## [0.0.1] - Published Feb 8, 2018.

* Record audio and store it locally
  
## [0.0.2] - Published May 16, 2018.

* Support Dart 2

## [0.0.3] - Published June 11, 2018.

* Update readme

## [0.0.4] - Published June 11, 2018.

* Added path of application directory to user's file name so that a valid file can be written in iOS.
* Added diagnostic info to help user find the location of their recorded file.

## [0.0.5] - Published August 16, 2018.

* Fix readme with the right class name
* Make Volume up when recording on iOS

## [0.0.6] - Published September 9, 2018.

* Added test and code coverage report for plugin

## [1.0.0] - Published July 4, 2019.

* Fix a bug where the MediaRecorder.AudioEncoder format AMR_NB create a confusion for some players
* Fix for flutter beta v0.10.2
* Add wav file support

## [1.0.1] - Published July 5, 2019.

* Fix swift version

## [1.0.2] - Published Marc 25, 2020.

* Fix build issues on android