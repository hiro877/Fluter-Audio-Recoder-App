# simple_permissions_example

Demonstrates how to use the simple_permissions plugin.

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).
