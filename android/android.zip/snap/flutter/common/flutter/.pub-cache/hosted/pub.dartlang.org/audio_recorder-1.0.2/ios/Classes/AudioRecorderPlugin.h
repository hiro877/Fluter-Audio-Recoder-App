#import <Flutter/Flutter.h>

@interface AudioRecorderPlugin : NSObject<FlutterPlugin>
@end
